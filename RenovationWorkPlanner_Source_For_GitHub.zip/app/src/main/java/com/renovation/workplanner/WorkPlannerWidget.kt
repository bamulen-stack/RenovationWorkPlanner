package com.renovation.workplanner

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray

class WorkPlannerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE)
        val weekJson = prefs.getString("weekJson", "[]") ?: "[]"
        val week = try { JSONArray(weekJson) } catch (_: Exception) { JSONArray() }
        val rowIds = intArrayOf(
            R.id.widget_day1, R.id.widget_day2, R.id.widget_day3, R.id.widget_day4,
            R.id.widget_day5, R.id.widget_day6, R.id.widget_day7
        )

        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_work_planner)
            views.setTextViewText(R.id.widget_title, "Weekly Calendar")
            for (i in 0..6) {
                val text = if (i < week.length()) {
                    val d = week.optJSONObject(i)
                    val label = d?.optString("label", "") ?: ""
                    val count = d?.optInt("count", 0) ?: 0
                    val summary = d?.optString("summary", "No tasks") ?: "No tasks"
                    if (count > 0) "$label  •  $summary${if (count > 1) "  (+${count - 1})" else ""}" else "$label  •  No tasks"
                } else ""
                views.setTextViewText(rowIds[i], text)
            }
            views.setTextViewText(R.id.widget_footer, "Tap to open Renovation Work Planner")

            val intent = Intent(context, MainActivity::class.java).apply {
                putExtra("openView", "calendar")
            }
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            manager.updateAppWidget(id, views)
        }
    }
}
