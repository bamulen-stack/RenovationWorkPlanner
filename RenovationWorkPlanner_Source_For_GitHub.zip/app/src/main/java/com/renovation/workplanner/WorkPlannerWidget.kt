package com.renovation.workplanner

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WorkPlannerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE)
        val today = prefs.getInt("todayCount", 0)
        val important = prefs.getInt("importantCount", 0)
        val nextTitle = prefs.getString("nextTitle", "Open planner to sync tasks") ?: ""
        val nextTime = prefs.getString("nextTime", "") ?: ""
        val nextProject = prefs.getString("nextProject", "") ?: ""

        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_work_planner)
            views.setTextViewText(R.id.widget_title, "Today: $today tasks")
            views.setTextViewText(
                R.id.widget_main,
                if (important > 0) "⚠ $important important • $nextTime $nextTitle"
                else "$nextTime $nextTitle"
            )
            views.setTextViewText(
                R.id.widget_sub,
                if (nextProject.isNotBlank()) nextProject else "Renovation Work Planner"
            )

            val intent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            manager.updateAppWidget(id, views)
        }
    }
}
