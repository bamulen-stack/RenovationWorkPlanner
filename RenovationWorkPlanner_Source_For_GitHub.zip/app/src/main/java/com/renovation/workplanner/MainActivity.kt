package com.renovation.workplanner

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        askNotificationPermission()

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "workplanner_reminders",
                "Work Planner reminders",
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.description = "Important renovation task reminders"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    class AndroidBridge(private val context: Context) {

        @JavascriptInterface
        fun updateWidget(json: String) {
            try {
                val o = JSONObject(json)
                context.getSharedPreferences("widget_data", Context.MODE_PRIVATE).edit()
                    .putInt("todayCount", o.optInt("todayCount", 0))
                    .putInt("importantCount", o.optInt("importantCount", 0))
                    .putString("nextTitle", o.optString("nextTitle", "No more tasks today"))
                    .putString("nextTime", o.optString("nextTime", ""))
                    .putString("nextProject", o.optString("nextProject", ""))
                    .apply()

                val manager = AppWidgetManager.getInstance(context)
                val component = ComponentName(context, WorkPlannerWidget::class.java)
                val ids = manager.getAppWidgetIds(component)
                val intent = Intent(context, WorkPlannerWidget::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun scheduleReminder(json: String) {
            try {
                val o = JSONObject(json)
                val date = o.optString("date")
                val start = o.optString("start", "09:00")
                val reminder = o.optLong("reminder", 0L)
                val title = o.optString("title", "Renovation task")
                val project = o.optString("projectName", "Renovation")
                val important = o.optBoolean("important", false)
                val id = o.optString("id", System.currentTimeMillis().toString())

                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                val due = sdf.parse("$date $start") ?: return
                val whenMs = due.time - reminder * 60_000L
                if (whenMs <= System.currentTimeMillis()) return

                val intent = Intent(context, ReminderReceiver::class.java).apply {
                    putExtra("title", if (important) "⚠ Important renovation task" else "Renovation Work Planner")
                    putExtra("body", "$project — $title at $start")
                }
                val pi = PendingIntent.getBroadcast(
                    context,
                    id.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                }
            } catch (_: Exception) {}
        }
    }
}
