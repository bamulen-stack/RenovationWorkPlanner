RENOVATION WORK PLANNER — FINAL ANDROID VERSION

Included:
- Fully offline mobile app
- English UI
- Today / Calendar / Projects / Workers
- Add tasks with date, start/end time, project, worker, status and notes
- Important task flag
- Reminder options: at time / 30 min before / 1 hour before / 1 day before
- Native Android notification channel and scheduled reminders
- Home-screen widget
- Widget syncs from the app and shows:
    • Today's open task count
    • Important task count
    • Next task time + title
    • Project name
- Tap widget to open app
- Resizable widget
- GitHub Actions automatic APK build workflow

INSTALLABLE APK:
The project includes .github/workflows/build-apk.yml.
Once placed in a GitHub repository, Actions builds:
app/build/outputs/apk/debug/app-debug.apk

Android package:
com.renovation.workplanner
